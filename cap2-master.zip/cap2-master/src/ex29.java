

public class ex29 {
    public static void main(String[] args) {
        int a = ((int) 'A');
        System.out.printf("the value char %c = %d \n",'A',a);
        System.out.printf("the value char %c = %d \n",'B',((int) 'B'));
        System.out.printf("the value char %c = %d \n",'C',((int) 'C'));
        System.out.printf("the value char %c = %d \n",'a',((int) 'a'));
        System.out.printf("the value char %c = %d \n",'b',((int) 'b'));
        System.out.printf("the value char %c = %d \n",'c',((int) 'c'));
        System.out.printf("the value char %c = %d \n",'0',((int) '0'));
        System.out.printf("the value char %c = %d \n",'1',((int) '1'));
        System.out.printf("the value char %c = %d \n",'2',((int) '2'));
        System.out.printf("the value char %c = %d \n",'+',((int) '+'));
        System.out.printf("the value char %c = %d \n",'$',((int) '$'));
        System.out.printf("the value char %c = %d \n",'*',((int) '*'));
        System.out.printf("the value char %c = %d \n",'/',((int) '/'));

    }
}
